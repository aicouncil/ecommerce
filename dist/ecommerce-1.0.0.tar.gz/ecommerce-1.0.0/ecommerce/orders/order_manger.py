def create_order(user,product,quantity):
    print(f"Order created for user '{user} for product '{product}' (x{quantity})")

def list_orders():
    print("Listing all orders")