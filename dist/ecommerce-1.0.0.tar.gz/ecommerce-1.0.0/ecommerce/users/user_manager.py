def add_user(username,email):
    print(f"User {username} added with email '{email}'")

def list_users():
    print("Listing all users......")