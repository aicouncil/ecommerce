def add_product(name,price,stock):
    print(f"Product '{name}' added with price '{price}' and stock '{stock}")

def list_products():
    print("Listing all products")